from functools import wraps
import asyncio, aiofiles, copy, time, os
from aiofiles import os as aiofilesos

filters = '\\,|*?<>:"\'\n\r\t/\x00\x0b\x0c'

def runner(func):
    async def wrapper(*args, **kwargs):
        async with asyncio.timeout(1):
            if len(args) == 3:
                res = await func(args[0], args[1], args[2])
            elif len(args) == 2:
                res = await func(args[0], args[1])
        return res
    return wrapper

class FM:
    def __init__(self):
        self.filters = list(enumerate(filters))

    async def filtercheck(self, extfilter=False):
        self.filters = list(enumerate(filters))
        if extfilter == True:
            if self.ext and self.ext not in [".png", ".txt", ".jpg"]:
                return "Only png, txt, jpg file!!"
        print(id(self.filters))
        for i, x in self.filters:
            if x in self.filename:
                return "Filtered.."
            print(extfilter, i,x)
        return True
    
    @runner
    async def read(self, filename):
        self.filename, self.ext = os.path.splitext(filename)
        res = await self.filtercheck(True)
        if res == True:
            async with aiofiles.open("./uploads/{}".format(filename), mode='rb') as f:
                contents = await f.read()
                return [contents, self.ext]
        else:
            return res

    @runner
    async def write(self, filename, data):
        self.filename = filename
        res = await self.filtercheck()
        if res == True:
            async with aiofiles.open("./uploads/{}".format(filename), mode='wb') as f:
                await f.write(data)
                return "Write Success!!"
        else:
            return res

    @runner
    async def delete(self, filename):
        self.filename = filename
        res = await self.filtercheck()
        if res == True:
            await aiofilesos.remove("./uploads/{}".format(filename))
            return "Delete Success!!"
        else:
            return res
