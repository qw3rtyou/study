from functools import wraps
from flask import Flask, request, render_template, make_response
from lib import utils
import asyncio, os, mimetypes, base64, sys

app = Flask(__name__)
FM = utils.FM()

@app.errorhandler(500)
def error(error):
    return make_response(str(sys.exc_info()[1]), 500)

@app.route("/")
def index():
    filelist = os.listdir("uploads")
    return render_template("index.html", board=filelist)

@app.route("/delete", methods=['POST'])
async def delete():
    res = await FM.delete(request.form["filename"])
    return render_template("res.html", res = res)

@app.route("/read", methods=['POST'])
async def read():
    res = await FM.read(request.form["filename"])
    if isinstance(res,list) and res[1] != None:
        response = make_response(res[0], 200)
        type = mimetypes.guess_type(request.form["filename"])[0]
        response.mimetype = type if type else "plain/text"
        return response
    return render_template("res.html", res = res)

@app.route("/write", methods=['GET', 'POST'])
async def write():
    if request.method == "POST":
        res = await FM.write(request.files["file"].filename, request.files["file"].read())
        return render_template("res.html", res = res)
    else:
        return render_template("write.html")

app.run(host="0.0.0.0", port=31337)