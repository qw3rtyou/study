const express    = require('express');
const mysql      = require('mysql');
const dbconfig   = require('./config/database.js');
const connection = mysql.createConnection(dbconfig);
var childProcess = require('child_process');
const addon = require("bindings")("game");
const crypto = require('crypto');
const fs = require("fs")
const session = require('express-session');
const Memorystore = require('memorystore')(session)
const app = express();
var map = {};
app.use(express.json())
app.use(express.urlencoded())
app.use(session({
  secure: true,
  secret: crypto.randomBytes(32).toString('hex'),
  resave: false,
  saveUninitialized: true,
  store: new Memorystore()
}));
app.set('port', process.env.PORT || 12121);

app.get('/', (req, res) => {
  res.sendFile(__dirname + "/views/index.html")
});

app.get('/game', (req, res) => {
  if(req.session.userid === undefined){
    res.redirect("/");
  }else{
    res.sendFile(__dirname + "/views/game.html")
  }
});

app.post('/login', (req, res) => {
  const {id, pw} = req.body
  if(id === undefined || pw === undefined){
    res.send("Plz check your id or pw")
  }
  connection.query('SELECT * from user where id=?', [id] , (error, rows) => {
    if (error) throw error;
    if(rows.length === 0){
      res.send("Not Found..")
    }
    else if(rows[0].pw === crypto.createHash('sha512').update(pw).digest('hex')){
      req.session.userid = id;
      res.redirect('/game');
    }
    else{
      res.send("Not Found..")
    }
  });
});

app.post('/register', (req, res) => {
  const {id, pw} = req.body
  if(id === undefined || pw === undefined){
    res.send("Plz check your id or pw")
  }
  connection.query('INSERT INTO user(id, pw) VALUES(?, ?)', [id, crypto.createHash('sha512').update(pw).digest('hex')] , (error, rows) => {
    if (error) throw error;
  });
  res.redirect('/');
});

app.get("/logout",function(req,res){
  req.session.destroy();
  res.redirect('/');    
});

app.post("/bomb_check",function(req,res){

  if(req.session.userid === undefined || req.session.filename === undefined){
    res.redirect("/");
  }else{
	  if(!(new String(req.session.filename).toString()).includes('flag'))
    {
      map = JSON.parse(fs.readFileSync(req.session.filename ,{encoding: "utf-8"}));
      res.send(map[req.body.x][req.body.y].toString() + "/" + map["difficulty"]);
    }
    else{
      res.send("No.");
    }	
  }
});

app.post("/gen_map",function(req,res){
  if(req.session.userid === undefined){
    res.redirect("/");
  }else{
    const json_getAllKeys = f=o=>Object.keys(o+''===o||o||0).flatMap(k=>[k,...f(o[k]).map(i=>k+"."+i)])
    keys = json_getAllKeys(req.body)
    if(keys.includes("__proto__") || keys.includes("prototype") || keys.includes("constructor")){
      res.send("Don't attack..!!");
    }
    key_pattern = /[`~!@#$%^&*()_|+\-=?;:'",<>\{\}\[\]\\\/]/gim;
    for(i in keys){
      if(key_pattern.test(keys[i])){
        res.send("Don't use specail chars..!!");
        break;
      }
    }
    map = addon.gen_map(req.body);
    req.session.filename = "/tmp/" + crypto.randomBytes(32).toString('hex') + ".map";
    fs.writeFileSync(req.session.filename, JSON.stringify(map));
    res.send("Success/" + map["difficulty"]);
    }
});


app.listen(app.get('port'), () => {
  console.log('Express server listening on port ' + app.get('port'));
});
