const crypto = require('crypto');
module.exports = {
    host     : 'mysql',
    user     : 'root',
    password : '4cda0baee5fe083edb890766f9a79173',
    database : 'test'
  };