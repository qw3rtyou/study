#!/bin/bash
/usr/bin/python3 -B app.py