import ast
import re
import os
import uuid

from flask import Flask, request, make_response, redirect, render_template, url_for

app = Flask(__name__)

# originated from GoogleCTF 2022 Treebox
def verify_secure(code):
    FORBIDDEN_CHARACTERS = '\'\"#@_=:[]{}\n'
    for ch in FORBIDDEN_CHARACTERS:
        if ch in code:
            return False

    tree = compile(code, "<string>", 'exec', flags=ast.PyCF_ONLY_AST)
    for node in ast.walk(tree):
        if \
            isinstance(node, ast.Import) or \
            isinstance(node, ast.ImportFrom) or \
            isinstance(node, ast.Call):
                return False

    return True

@app.get('/')
def app_index():
    session = request.cookies.get('session', '')
    new_session = str(uuid.uuid4()) if not session else None
    if new_session:
        session = new_session

    UUID_PATTERN = '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    if not isinstance(session, str) or not re.match(UUID_PATTERN, session):
        return make_response({'success' : 'false', 'message' : 'invalid session'}, 400)

    session_dir = './sessions/{}'.format(session)
    os.makedirs(session_dir, exist_ok=True)
    files = os.listdir(session_dir)

    response = make_response(render_template('index.html', files=files))
    if new_session:
        response.set_cookie('session', new_session)
    return response

@app.post('/')
def app_index_post():
    return redirect('/')

@app.post('/new')
def app_new():
    session = request.cookies.get('session', '')
    UUID_PATTERN = '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    if not isinstance(session, str) or not re.match(UUID_PATTERN, session):
        return make_response({'success' : 'false', 'message' : 'invalid session'}, 400)

    name = request.form.get('name', None)
    if not isinstance(name, str):
        return make_response({'success' : 'false', 'message' : 'invalid name'}, 400)

    expression = request.form.get('expression', None)
    if not isinstance(expression, str):
        return make_response({'success' : 'false', 'message' : 'invalid expression'}, 400)

    with open('./sessions/{}/{}'.format(session, name), 'w') as f:
        f.write(expression)

    return make_response({'success' : 'true'}, 200)

@app.post('/delete')
def app_delete():
    session = request.cookies.get('session', None)

    UUID_PATTERN = '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    if not isinstance(session, str) or not re.match(UUID_PATTERN, session):
        return make_response({'success' : 'false', 'message' : 'invalid session'}, 400)

    name = request.form.get('name', None)
    if not isinstance(name, str):
        return make_response({'success' : 'false', 'message' : 'invalid name'}, 400)

    os.unlink('./sessions/{}/{}'.format(session, name))

    return make_response({'success' : 'true'}, 200)

@app.post('/evaluate')
def app_evaluate():
    session = request.cookies.get('session', None)

    UUID_PATTERN = '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
    if not isinstance(session, str) or not re.match(UUID_PATTERN, session):
        return make_response({'success' : 'false', 'message' : 'invalid session'}, 400)

    name = request.form.get('name', None)
    if not isinstance(name, str):
        return make_response({'success' : 'false', 'message' : 'invalid name'}, 400)

    with open('./sessions/{}/{}'.format(session, name), 'r') as f:
        code = f.read()

    if verify_secure(code):
        context = {}
        exec('result = ' + code, context)
        return make_response({'success' : 'true', 'result' : str(context.get('result'))}, 200)
    else:
        return make_response({'success' : 'false', 'message' : 'invalid code'}, 400)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=45510, debug=False, threaded=False)
