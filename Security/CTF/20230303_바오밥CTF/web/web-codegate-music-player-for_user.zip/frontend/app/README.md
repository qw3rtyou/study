## Memo

1. Packages are the latest
   (as of 2023 June)
2. This is a ChatGPT-oriented CTF challenge
   (Ref. https://twitter.com/brokenpacifist/status/1650955597414809600)
3. Frontend src is deleted as per the license policy. We'll only provide the built src. 
   I know it's an evil thing to not disclose the frontend sourcecode, but good luck solving the challenge!
